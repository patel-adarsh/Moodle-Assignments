package com.capgemini.assignment8;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Restq8ApplicationTests {

	@Test
	void contextLoads() {
	}

}
