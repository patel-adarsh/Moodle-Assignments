package com.capgemini.assignment5;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Restq5Application {

	public static void main(String[] args) {
		SpringApplication.run(Restq5Application.class, args);
	}

}
