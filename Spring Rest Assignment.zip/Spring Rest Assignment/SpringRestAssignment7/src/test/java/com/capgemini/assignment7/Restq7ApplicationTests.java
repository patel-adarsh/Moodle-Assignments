package com.capgemini.assignment7;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Restq7ApplicationTests {

	@Test
	void contextLoads() {
	}

}
