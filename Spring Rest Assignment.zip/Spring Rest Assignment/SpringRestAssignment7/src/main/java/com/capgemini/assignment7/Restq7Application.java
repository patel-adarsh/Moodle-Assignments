package com.capgemini.assignment7;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Restq7Application {

	public static void main(String[] args) {
		SpringApplication.run(Restq7Application.class, args);
	}

}
