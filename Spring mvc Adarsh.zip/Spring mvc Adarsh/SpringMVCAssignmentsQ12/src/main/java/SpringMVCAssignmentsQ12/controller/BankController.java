package SpringMVCAssignmentsQ12.controller;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class BankController {
	
	@RequestMapping(value = "/bank", method = RequestMethod.GET)
	public String demo() {
		return "detail";
	}

	@RequestMapping(value = "/bank2", method = RequestMethod.POST)
	public String demo2(@Valid @ModelAttribute("U") User U,Model m, BindingResult r ) {
		System.out.println(U);
//		if(r.hasErrors()) {
//			return "Exception";
		if(U.getBalance()>5000) {
			m.addAttribute("msg","You don't have enough balance!! please put the balance below than 5000");
		}else {
			m.addAttribute("msg","Minimum balance required in your account 5000");
		}
		
		
		return "detail2";
	}
}
