package SpringMVCAssignmentsQ12.controller;

import javax.validation.constraints.Size;

public class User {
	
	@Size(min = 1, max = 2)
	private String accountno;
	
	
	private int balance;


	public String getAccountno() {
		return accountno;
	}


	public void setAccountno(String accountno) {
		this.accountno = accountno;
	}


	public int getBalance() {
		return balance;
	}


	public void setBalance(int balance) {
		this.balance = balance;
	}


	@Override
	public String toString() {
		return "User [accountno=" + accountno + ", balance=" + balance + "]";
	}
	

}